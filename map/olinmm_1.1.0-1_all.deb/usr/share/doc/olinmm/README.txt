  The Marauder's Map @ Olin


      76 Access Points + Software = Localization

The Marauder's Map @ Olin is an opt-in program that utilizes Olin's
wireless access points to generate a map of laptop locations on campus.
By training the system, we correlate access point signal strength to
location. Currently, this method is able to achieve approximately
room-level accuracy.


      News


        3/1/2008 - Release Candidate 1

With all the suggestions from the beta we have revamped the web
interface and improved the client GUI. Accuracy is also improved.


        2/5/2008 - Beta Closed

The beta test is now closed on account of me turning my computer off at
night. Thanks for all of your suggestions and bug reports!


        1/24/2008 -- Beta Released

Our first public test! We have about 10 beta testers on campus, selected
through the very scientific method of walking around and asking if
people wanted to try it out.


      Disclaimer!

Some of you are thinking "Wow, this is creepy." Yes, tracking locations
is a privacy issue. This is an opt-in project. If you don't want to be
tracked, don't install. If you want to be tracked some of the time, turn
the client off when you don't want to be found. We do not keep any logs
of location data -- as soon as your location is updated your old
information is overwritten. Keep in mind that just because we do not log
the data doesn't mean that logging isn't possible. The information is
public inside of Olin. That being said, don't log the data. /Respect for
Others./

------------------------------------------------------------------------

The Marauder's Map @ Olin utilizes wxPython <http://www.wxpython.org>,
PHP <http://www.php.net>, and MySQL <http://www.mysql.com>.

------------------------------------------------------------------------
Developed by Andrew Barry <mailto:andy@students.olin.edu> and Ben Fisher
<mailto:Benjamin.Fisher@students.olin.edu>

